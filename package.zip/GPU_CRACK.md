# Crack kunci DES EAJet/GT1000 di GPU cloud (hashcat -m 14000)

Tujuan: temukan kunci DES 8-byte dari pasangan known-plaintext
`CT = DES(key, challenge||00000000)`. Mode hashcat **14000** (raw DES,
known-plaintext). Plaintext kita **100% diketahui** → kasus termudah.

## 0. Jujur dulu (baca ini)
- **DES itu ramah-FPGA, bukan ramah-GPU.** crack.sh (48 FPGA) menyapu 2^56
  dalam ~26 jam. Di GPU, `-m 14000` bisa cepat (ratusan GH/s, mirip LM) ATAU
  lambat (beberapa GH/s, mirip descrypt) — **tidak pasti tanpa benchmark.**
- Karena itu: **sewa 1 GPU dulu, benchmark, baru putuskan** berapa GPU / apakah
  lanjut GPU atau tunggu crack.sh (FPGA) / pakai AWS F1 (instance FPGA).

Perkiraan 2^56 = 7.2e16 kandidat:
| Laju (per GPU) | 1 GPU | 8 GPU |
|---|---|---|
| 4 GH/s (lambat/descrypt) | ~208 hari | ~26 hari |
| 50 GH/s | ~17 hari | ~2 hari |
| 150 GH/s (cepat/LM) | ~5.5 hari | ~17 jam |

## 1. Sewa GPU (vast.ai / runpod)
1. Daftar di https://vast.ai (atau runpod.io), isi saldo.
2. Sewa instance: filter **RTX 4090** (1× untuk benchmark). Pilih template
   image dengan CUDA/NVIDIA driver (mis. "NVIDIA CUDA" / "PyTorch"), disk 20GB.
3. Buka terminal/SSH ke instance.

## 2. Pasang hashcat (versi resmi, bukan apt yang sering usang)
```bash
cd /root
wget https://hashcat.net/files/hashcat-6.2.6.7z   # atau versi terbaru dari hashcat.net
apt-get update && apt-get install -y p7zip-full
7z x hashcat-6.2.6.7z && cd hashcat-6.2.6
./hashcat.bin -I     # pastikan GPU terdeteksi
```

## 3. BENCHMARK dulu (wajib)
```bash
./hashcat.bin -b -m 14000
```
Catat angka **H/s**. Hitung waktu = 7.2e16 / (H/s × jumlah_GPU).
Kalau terlalu lama/mahal → berhenti, tunggu crack.sh atau pakai FPGA (AWS F1).

## 4. Siapkan hash + charset
```bash
echo "9a703f723e58e4d4:f26a574a00000000" > hash.txt
# charset DES_full: pakai bawaan hashcat, atau file DES_full.hcchr dari folder keycrack
CHR=$(find / -name 'DES_full.hcchr' 2>/dev/null | head -1)
CHR=${CHR:-charsets/DES_full.hcchr}
echo "charset: $CHR"
```
(`hash.txt` = ciphertext:plaintext. Pasangan lain ada di `extauth_hashcat.txt`.)

## 5. Jalankan crack
```bash
./hashcat.bin -m 14000 -a 3 hash.txt -1 "$CHR" --hex-charset ?1?1?1?1?1?1?1?1 --markov-disable -w 4
```
- `-w 4` = workload tinggi. Tambah `-d 1,2,3,...` kalau multi-GPU tidak otomatis.
- Pantau ETA di layar. Hasil (key) muncul saat ketemu; cek juga `--show`:
  `./hashcat.bin -m 14000 hash.txt --show`

## 6. Setelah kunci ketemu
1. hashcat memberi key 8-byte (hex). Verifikasi di PC Anda:
   `py keycrack\verify_key.py <KUNCIHEX>`  → harus **8/8 external-auth cocok**.
2. Kirim kuncinya ke saya → saya tanam DES ke `proxmark_patch\eajet_sim.c` supaya
   emulator menghitung MAC untuk **state baru apa pun** → **klon yang tak pernah
   error** (tak perlu re-accept tiap ~400 cetak).

## Alternatif FPGA (paling efisien untuk DES)
- **crack.sh** (down maintenance) — token siap di `cracksh_tokens.txt`.
- **AWS EC2 F1** (instance FPGA) — jalankan DES brute di FPGA; jauh lebih
  efisien dari GPU untuk DES. Perlu bitstream DES brute (proyek open-source ada).
