"""Buat token submission crack.sh (des_kpt) untuk pasangan known-plaintext kita.

crack.sh des_kpt: CT = DES(key, PT_block), PT_block = challenge||00000000 (100%
diketahui, mask = semua-satu). Token = PREFIX + base64(PT_masked || mask || CT),
PREFIX $98$ untuk E=0 (encrypt). Diverifikasi dulu terhadap contoh resmi crack.sh.
"""
from __future__ import annotations
import base64

PAIRS = [
    ("f26a574a00000000", "9a703f723e58e4d4"),
    ("ecc8300b00000000", "db2333da279a1436"),
    ("7290f1dc00000000", "4b6c5de6da6b451c"),
    ("e2c61f2500000000", "139b5ea0b835d33f"),
    ("dbd0fbe400000000", "67d01dc0be7c9918"),
    ("440570cf00000000", "ddda1ca2cff7eb8f"),
    ("39f3696500000000", "eb47a31cbc092362"),
    ("59e1622f00000000", "ee500b9ca30491c0"),
]


def token(pt_hex: str, mask_hex: str, ct_hex: str, E: int = 0) -> str:
    # crack.sh encodes PT in full; only CT is masked, and only for E=1.
    pt = bytes.fromhex(pt_hex); m = bytes.fromhex(mask_hex); ct = bytes.fromhex(ct_hex)
    if E:
        ctm = bytes(a & b for a, b in zip(ct, m))
        return "$97$" + base64.b64encode(pt + m + ctm).decode()
    return "$98$" + base64.b64encode(pt + m + ct).decode()


# --- verifikasi terhadap contoh resmi crack.sh ---
ex = token("0123456789abcdef", "ffffffffffff0000", "825f48ccfd6829f0", 0)
exp = "$98$ASNFZ4mrze////////8AAIJfSMz9aCnw"
print(f"[selftest] {ex}  == {exp}  -> {ex == exp}")
ex2 = token("0123456789abcdef", "ffffffffffff0000", "825f48ccfd6829f0", 1)
exp2 = "$97$ASNFZ4mrze////////8AAIJfSMz9aAAA"
print(f"[selftest] {ex2}  == {exp2}  -> {ex2 == exp2}")

if ex != exp or ex2 != exp2:
    print("\n[!] format token TIDAK cocok dengan contoh resmi — JANGAN pakai, gunakan des_kpt.py asli dari crack.sh.")
else:
    print("\n[ok] format cocok. Token untuk pasangan kita (mask = ffffffffffffffff, semua diketahui):\n")
    FULL = "ffffffffffffffff"
    for pt, ct in PAIRS:
        print(f"  PT={pt}  CT={ct}")
        print(f"    token = {token(pt, FULL, ct, 0)}")
    print("\nKirim salah satu token di atas ke halaman Get Cracking crack.sh (job Known Plaintext DES).")
