# Pemulihan Kunci DES EAJet/GT1000 (keycrack)

## Ringkasan: kenapa folder ini ada

Uji **rantai replay** (S1→S2→S3→S4→E) sudah dijalankan dan **GAGAL secara
meyakinkan** (lihat `logs\printer_S1_20261027_170452.log`):

1. Printer membaca state S1, lalu **secure-read 0006/0007 DITERIMA** — MAC
   replay S1 (`9de904fa`, `29a0910f`) valid, printer lanjut.
2. Printer lalu **menulis `file0004` baru** (tail `6E26`, lalu `6726`) yang
   isinya **tidak cocok dengan state tangkapan mana pun** (`found=-1`).
3. Mode 0 mengembalikan S1 lama saat dibaca ulang → **tidak sama** → printer
   coba ulang 10×, ganti tail, lalu **Check-02**.

Printer **tidak pernah** sampai secure-update: ia sudah menolak di readback
`file0004`. Menyimpan tulisan asing (mode 1/4) hanya memindah tembok satu
langkah ke MAC secure-read, yang tetap butuh kunci.

**Kesimpulan: tidak ada jalur klon tanpa kunci (keyless).** Printer selalu
menulis state baru (counter tinta bergantung waktu/internal, bukan fungsi
sederhana dari state yang dibaca) dan menuntut MAC yang valid untuk state itu.

## Yang dibutuhkan: satu kunci DES 8-byte

MAC line-protection & external-auth memakai **Single DES** (terkonfirmasi: vektor
manual `1122334455667788` / `0102030405060708` → `A82A8CEB`). Kunci 8 byte =
efektif 56-bit → **bisa di-brute-force**.

Kunci **tidak** ada sebagai konstanta di biner yang kita punya (`__EAJet.exe`,
`firmware.bin`) — kemungkinan tersimpan di **firmware modul reader RFID**
(chip terpisah) dan/atau dipakai global untuk semua cartridge.

Pencarian cerdas sudah dicoba dan **nihil**: default FMCOS, string ASCII
(EAJET/GT1000/FMCOS/…), turunan UID, dan diversifikasi `DES(master, UID)` —
tak satupun cocok. Jadi tersisa brute-force penuh atau ekstraksi hardware.

## Bahan brute-force yang sudah siap

8 pasang **known-plaintext** dari EXTERNAL AUTHENTICATE (P2=00), direkam dari
trace printer↔kartu asli:

```
ciphertext = DES_ECB(kunci, challenge || 00000000)
```

- `keycrack\extauth_hashcat.txt` — format `ciphertext:plaintext` untuk hashcat.
- `py keycrack\verify_key.py --pairs` — daftar pasangan.

Satu kunci yang cocok untuk ke-8 pasang hampir pasti benar (blok 64-bit).

## Cara memecah kunci

### Opsi A — hashcat -m 14000 (raw DES known-plaintext), di GPU
```bash
# hash.txt = satu baris dari extauth_hashcat.txt, mis:
#   9a703f723e58e4d4:f26a574a00000000
hashcat -m 14000 -a 3 hash.txt -1 charsets/DES_full.hcchr --hex-charset ?1?1?1?1?1?1?1?1
```
- Ruang 2^56. Perkiraan kasar: ±beberapa hari di rig multi-GPU, atau sewa
  GPU cloud (vast.ai/runpod) beberapa hari. Satu GPU saja bisa berminggu-minggu.
- Setelah hashcat memberi kunci, **verifikasi**:
  `py keycrack\verify_key.py <KUNCIHEX>` — harus 8/8 external-auth cocok.

### Opsi B — layanan crack DES (mis. crack.sh)
- Dulu memecah single-DES known-plaintext dalam ±1 hari pakai FPGA. Status
  2026 tidak pasti (mungkin offline) — cek dulu. Kirim satu pasang
  `plaintext/ciphertext` dari `extauth_hashcat.txt`.

### Opsi C — ekstraksi hardware (paling pasti)
- Dump firmware/EEPROM **modul reader RFID** di dalam printer (bukan board
  utama). Kunci ada di situ. Butuh buka printer + programmer chip.

## Sesudah kunci ketemu

1. `py keycrack\verify_key.py <KUNCI>` → pastikan 8/8 external-auth **dan**
   cek response-MAC (kalau juga cocok: satu kunci untuk semuanya).
2. Tanam DES + kunci ke emulator (`proxmark_patch\eajet_sim.c`): hitung
   response-MAC `DES_CBC_MAC(kunci, data40, IV=challenge||00000000)` secara
   dinamis untuk **state baru apa pun** yang ditulis printer → **klon permanen**
   tanpa perlu rantai tangkapan.

## Berkas

- `des.py` — DES murni (pustaka standar), teruji 2 vektor tepercaya.
- `verify_key.py` — verifikasi kandidat kunci (external-auth + response-MAC).
- `extauth_hashcat.txt` — input hashcat -m 14000.
