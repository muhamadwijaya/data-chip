"""Verifikasi kandidat kunci DES EAJet/GT1000.

Pemakaian:
    py keycrack\verify_key.py 0123456789ABCDEF      # uji satu kunci (hex 8 byte)
    py keycrack\verify_key.py --pairs               # cetak pasangan known-plaintext
    py keycrack\verify_key.py --hashcat             # cetak baris input hashcat -m 14000

Uji UTAMA (menentukan): EXTERNAL AUTHENTICATE
    ciphertext = DES_ECB(kunci, challenge || 00000000)
8 pasang direkam dari trace printer<->kartu asli (P2=00).  Satu kunci yang
cocok untuk ke-8 pasang hampir pasti kunci yang benar (blok 64-bit, kunci
56-bit -> praktis tanpa false positive).

Uji TAMBAHAN (informasional): response MAC secure-read 0006/0007
    mac4 = DES_CBC_MAC(kunci, data40, IV = challenge || 00000000)[:4]
Kalau ini juga lolos, kunci line-protection = kunci external-auth (satu kunci
untuk semuanya) dan emulator bisa menghitung MAC untuk state baru apa pun.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from des import des_encrypt, des_cbc_mac  # noqa: E402

# --- EXTERNAL AUTH known-plaintext (P2=00), dari trace_parsed.txt ---
# (challenge4, ciphertext8); plaintext = challenge || 00000000
EXTAUTH = [
    ("f26a574a", "9a703f723e58e4d4"),
    ("ecc8300b", "db2333da279a1436"),
    ("7290f1dc", "4b6c5de6da6b451c"),
    ("e2c61f25", "139b5ea0b835d33f"),
    ("dbd0fbe4", "67d01dc0be7c9918"),
    ("440570cf", "ddda1ca2cff7eb8f"),
    ("39f36965", "eb47a31cbc092362"),
    ("59e1622f", "ee500b9ca30491c0"),
]

# --- secure-read response MAC triples: (nama, challenge4, data40_hex, mac4_hex) ---
# Diambil dari gtink/replay.py (kartu asli, state A/C/E/S1).
SECMAC = [
    ("A.0006", "691d4fc3", "3368d89983278d9f75f0e5d3b70f83877b01ed14f70f12254f94456a05a78f9f40824db244a8a018", "37e1dd06"),
    ("A.0007", "1a6ace1f", "3368d89983278d9f75f0e5d3b70f83877b01ed14f70f12254f94456a05a78f9f40824db244a8a018", "54e832b6"),
    ("C.0006", "b9be715f", "3368d89983278d9f75f0e5d3b70f83877b01ed14f70f1226499e317af4a78f9f40824dba44a82018", "5e327b97"),
    ("E.0006", "5ce27f48", "3368d89983278d9f75f0e5d3b70f83877b01ed14f70f12a3509a3da2d48a8f9f40824dda44a86818", "cda9f666"),
    ("S1.0006", "6896080f", "3368d89983278d9f75f0e5d3b70f83877b01ed14f70fd1a64a96455a55aa8f9f40824dda44a82818", "9de904fa"),
]


def test_extauth_key(key8: bytes):
    """True bila kunci cocok untuk SEMUA pasang external-auth."""
    for ch, ct in EXTAUTH:
        pt = bytes.fromhex(ch) + bytes(4)
        if des_encrypt(key8, pt) != bytes.fromhex(ct):
            return False
    return True


def check(key8: bytes) -> None:
    print(f"Kunci: {key8.hex().upper()}\n")
    print("== External auth (DES ECB) — UTAMA ==")
    ok = 0
    for ch, ct in EXTAUTH:
        got = des_encrypt(key8, bytes.fromhex(ch) + bytes(4)).hex()
        good = got == ct
        ok += good
        print(f"  {ch}00000000 -> {got}  (harap {ct})  {'OK' if good else 'x'}")
    print(f"  => {ok}/{len(EXTAUTH)} cocok")
    print("\n== Response MAC secure-read (DES CBC-MAC) — tambahan ==")
    ok2 = 0
    for name, ch, data, mac in SECMAC:
        iv = bytes.fromhex(ch) + bytes(4)
        got = des_cbc_mac(key8, bytes.fromhex(data), iv=iv).hex()
        good = got == mac
        ok2 += good
        print(f"  {name}: {got}  (harap {mac})  {'OK' if good else 'x'}")
    print(f"  => {ok2}/{len(SECMAC)} cocok")
    print()
    if ok == len(EXTAUTH):
        print("*** KUNCI EXTERNAL-AUTH BENAR ***")
        if ok2 == len(SECMAC):
            print("*** Sekaligus kunci line-protection: satu kunci untuk semua. "
                  "Emulator bisa hitung MAC state baru -> klon permanen. ***")
        else:
            print("Catatan: external-auth benar tapi response-MAC tidak cocok. "
                  "Kunci line-protection mungkin beda, atau detail algoritme MAC "
                  "perlu dicek ulang.")
    else:
        print("[x] Kunci tidak cocok.")


def print_pairs() -> None:
    print("# EXTERNAL AUTH known-plaintext (P2=00)")
    print("# plaintext = challenge || 00000000 ; ciphertext = DES_ECB(key, plaintext)")
    print("# plaintext            ciphertext")
    for ch, ct in EXTAUTH:
        print(f"{ch}00000000   {ct}")


def print_hashcat() -> None:
    # hashcat -m 14000 format: ciphertext:plaintext (keduanya 16 hex / 8 byte)
    for ch, ct in EXTAUTH:
        print(f"{ct}:{ch}00000000")


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    if sys.argv[1] == "--pairs":
        print_pairs(); return 0
    if sys.argv[1] == "--hashcat":
        print_hashcat(); return 0
    h = sys.argv[1].replace(" ", "").replace(":", "")
    try:
        key8 = bytes.fromhex(h)
    except ValueError:
        print("kunci harus hex"); return 2
    if len(key8) != 8:
        print(f"kunci harus 8 byte, dapat {len(key8)}"); return 2
    check(key8)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
