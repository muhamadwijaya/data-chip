/* desbrute.c — pencarian kunci DES terstruktur untuk EAJet/GT1000.
 *
 * Brute-force ruang kunci berpola (charset^8) terhadap pasangan
 * known-plaintext external-auth: CT = DES_ECB(K, challenge||00000000).
 * Bukan brute-force 2^56 penuh — hanya kunci yang byte-nya dari satu charset.
 *
 * Build : gcc -O3 -fopenmp desbrute.c -o desbrute.exe
 * Jalan : desbrute.exe <charset>
 *         charset = digits|lower|upper|alnum_upper|alnum|hex|printable
 * Self-test DES (vektor nol + FMCOS CBC-MAC) jalan otomatis saat start.
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#ifdef _OPENMP
#include <omp.h>
#endif

static const int IP[64]={58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,
62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8,57,49,41,33,25,17,9,1,
59,51,43,35,27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7};
static const int FP[64]={40,8,48,16,56,24,64,32,39,7,47,15,55,23,63,31,
38,6,46,14,54,22,62,30,37,5,45,13,53,21,61,29,36,4,44,12,52,20,60,28,
35,3,43,11,51,19,59,27,34,2,42,10,50,18,58,26,33,1,41,9,49,17,57,25};
static const int E[48]={32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,
15,16,17,16,17,18,19,20,21,20,21,22,23,24,25,24,25,26,27,28,29,28,29,30,31,32,1};
static const int P[32]={16,7,20,21,29,12,28,17,1,15,23,26,5,18,31,10,
2,8,24,14,32,27,3,9,19,13,30,6,22,11,4,25};
static const int PC1[56]={57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,
59,51,43,35,27,19,11,3,60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,
30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4};
static const int PC2[48]={14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,
26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,
34,53,46,42,50,36,29,32};
static const int SHIFTS[16]={1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1};
static const int S[8][4][16]={
{{14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7},{0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8},{4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0},{15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13}},
{{15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10},{3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5},{0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15},{13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9}},
{{10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8},{13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1},{13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7},{1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12}},
{{7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15},{13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9},{10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4},{3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14}},
{{2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9},{14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6},{4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14},{11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3}},
{{12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11},{10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8},{9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6},{4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13}},
{{4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1},{13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6},{1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2},{6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12}},
{{13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7},{1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2},{7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8},{2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11}},
};

static uint32_t SP[8][64];

static void init_sp(void){
    for(int s=0;s<8;s++)for(int in=0;in<64;in++){
        int row=(((in>>5)&1)<<1)|(in&1), col=(in>>1)&0xF, val=S[s][row][col];
        uint32_t slayer=0;
        for(int b=0;b<4;b++) if((val>>(3-b))&1) slayer|=(1u<<(31-(4*s+b)));
        uint32_t out=0;
        for(int r=0;r<32;r++){ int src=P[r]-1; if((slayer>>(31-src))&1) out|=(1u<<(31-r)); }
        SP[s][in]=out;
    }
}

static uint64_t b2u(const uint8_t*b){ uint64_t x=0; for(int i=0;i<8;i++) x=(x<<8)|b[i]; return x; }
static void u2b(uint64_t x,uint8_t*b){ for(int i=7;i>=0;i--){ b[i]=x&0xFF; x>>=8; } }

static void des_ks(const uint8_t key[8], uint64_t sk[16]){
    uint64_t k=b2u(key), cd=0;
    for(int j=0;j<56;j++) cd=(cd<<1)|((k>>(64-PC1[j]))&1);
    uint32_t C=(cd>>28)&0x0FFFFFFF, D=cd&0x0FFFFFFF;
    for(int i=0;i<16;i++){
        int s=SHIFTS[i];
        C=((C<<s)|(C>>(28-s)))&0x0FFFFFFF;
        D=((D<<s)|(D>>(28-s)))&0x0FFFFFFF;
        uint64_t cd2=((uint64_t)C<<28)|D, k48=0;
        for(int j=0;j<48;j++) k48=(k48<<1)|((cd2>>(56-PC2[j]))&1);
        sk[i]=k48;
    }
}

static inline uint32_t feistel(uint32_t R, uint64_t k){
    uint64_t e=0;
    for(int i=0;i<48;i++) e=(e<<1)|((R>>(32-E[i]))&1);
    e^=k;
    uint32_t f=0;
    for(int g=0;g<8;g++) f^=SP[g][(e>>(42-6*g))&0x3F];
    return f;
}

static void des_enc(const uint64_t sk[16], const uint8_t in[8], uint8_t out[8]){
    uint64_t x=b2u(in), ip=0;
    for(int k=0;k<64;k++) ip=(ip<<1)|((x>>(64-IP[k]))&1);
    uint32_t L=(uint32_t)(ip>>32), R=(uint32_t)(ip&0xFFFFFFFF);
    for(int i=0;i<16;i++){ uint32_t t=R; R=L^feistel(R,sk[i]); L=t; }
    uint64_t pre=((uint64_t)R<<32)|L, fp=0;
    for(int k=0;k<64;k++) fp=(fp<<1)|((pre>>(64-FP[k]))&1);
    u2b(fp,out);
}

/* known-plaintext external-auth pairs (P2=00) */
#define NP 8
static const uint8_t PT[NP][8]={
 {0xf2,0x6a,0x57,0x4a,0,0,0,0},{0xec,0xc8,0x30,0x0b,0,0,0,0},
 {0x72,0x90,0xf1,0xdc,0,0,0,0},{0xe2,0xc6,0x1f,0x25,0,0,0,0},
 {0xdb,0xd0,0xfb,0xe4,0,0,0,0},{0x44,0x05,0x70,0xcf,0,0,0,0},
 {0x39,0xf3,0x69,0x65,0,0,0,0},{0x59,0xe1,0x62,0x2f,0,0,0,0}};
static const uint8_t CT[NP][8]={
 {0x9a,0x70,0x3f,0x72,0x3e,0x58,0xe4,0xd4},{0xdb,0x23,0x33,0xda,0x27,0x9a,0x14,0x36},
 {0x4b,0x6c,0x5d,0xe6,0xda,0x6b,0x45,0x1c},{0x13,0x9b,0x5e,0xa0,0xb8,0x35,0xd3,0x3f},
 {0x67,0xd0,0x1d,0xc0,0xbe,0x7c,0x99,0x18},{0xdd,0xda,0x1c,0xa2,0xcf,0xf7,0xeb,0x8f},
 {0xeb,0x47,0xa3,0x1c,0xbc,0x09,0x23,0x62},{0xee,0x50,0x0b,0x9c,0xa3,0x04,0x91,0xc0}};

static int verify_all(const uint8_t key[8]){
    uint64_t sk[16]; des_ks(key,sk); uint8_t o[8];
    for(int i=0;i<NP;i++){ des_enc(sk,PT[i],o); if(memcmp(o,CT[i],8)) return 0; }
    return 1;
}

static int selftest(void){
    uint64_t sk[16]; uint8_t z[8]={0},o[8];
    des_ks(z,sk); des_enc(sk,z,o);
    const uint8_t exp1[8]={0x8c,0xa6,0x4d,0xe9,0xc1,0xb1,0x23,0xa7};
    if(memcmp(o,exp1,8)){ printf("[x] DES zero-vector FAIL\n"); return 0; }
    /* FMCOS CBC-MAC: key 1122334455667788, data 0102030405060708, pad 80.. -> A82A8CEB */
    uint8_t mk[8]={0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88};
    uint8_t b1[8]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
    uint8_t b2[8]={0x80,0,0,0,0,0,0,0}, c1[8], x[8], c2[8];
    des_ks(mk,sk); des_enc(sk,b1,c1);
    for(int i=0;i<8;i++) x[i]=b2[i]^c1[i];
    des_enc(sk,x,c2);
    const uint8_t expm[4]={0xa8,0x2a,0x8c,0xeb};
    if(memcmp(c2,expm,4)){ printf("[x] FMCOS CBC-MAC FAIL\n"); return 0; }
    printf("[ok] DES self-tests passed\n");
    return 1;
}

static volatile int g_found=0;
static uint8_t g_key[8];

int main(int argc,char**argv){
    init_sp();
    if(!selftest()) return 1;
    const char*name = (argc>1)?argv[1]:"digits";
    char cs[128]; int n=0;
    if(!strcmp(name,"digits")) for(int c='0';c<='9';c++) cs[n++]=c;
    else if(!strcmp(name,"lower")) for(int c='a';c<='z';c++) cs[n++]=c;
    else if(!strcmp(name,"upper")) for(int c='A';c<='Z';c++) cs[n++]=c;
    else if(!strcmp(name,"hex")) { for(int c='0';c<='9';c++) cs[n++]=c; for(int c='a';c<='f';c++) cs[n++]=c; }
    else if(!strcmp(name,"alnum_upper")) { for(int c='0';c<='9';c++) cs[n++]=c; for(int c='A';c<='Z';c++) cs[n++]=c; }
    else if(!strcmp(name,"alnum")) { for(int c='0';c<='9';c++) cs[n++]=c; for(int c='A';c<='Z';c++) cs[n++]=c; for(int c='a';c<='z';c++) cs[n++]=c; }
    else if(!strcmp(name,"printable")) for(int c=0x20;c<=0x7e;c++) cs[n++]=c;
    else { printf("charset tak dikenal: %s\n",name); return 2; }

    double total=1; for(int i=0;i<8;i++) total*=n;
    printf("[*] charset=%s n=%d keyspace=%.3g (8 byte)\n",name,n,total);
    time_t t0=time(NULL);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for(int a=0;a<n;a++){
        if(g_found) continue;
        uint8_t key[8]; uint64_t sk[16]; uint8_t o[8];
        key[0]=cs[a];
        for(int b=0;b<n;b++){ key[1]=cs[b];
        for(int c=0;c<n;c++){ key[2]=cs[c];
        for(int d=0;d<n;d++){ key[3]=cs[d];
        for(int e=0;e<n;e++){ key[4]=cs[e];
        for(int f=0;f<n;f++){ key[5]=cs[f];
        for(int g=0;g<n;g++){ key[6]=cs[g];
        for(int h=0;h<n;h++){ key[7]=cs[h];
            des_ks(key,sk); des_enc(sk,PT[0],o);
            if(o[0]==CT[0][0] && memcmp(o,CT[0],8)==0){
                if(verify_all(key)){
#ifdef _OPENMP
                    #pragma omp critical
#endif
                    { g_found=1; memcpy(g_key,key,8); }
                }
            }
        }}}}}}}
        if(g_found) continue;
        time_t now=time(NULL);
        double frac=(double)(a+1)/n;
        fprintf(stderr,"[outer %d/%d  %.1f%%  %llds]\n",a+1,n,frac*100,(long long)(now-t0));
    }

    if(g_found){
        printf("\n*** KEY FOUND: ");
        for(int i=0;i<8;i++) printf("%02X",g_key[i]);
        printf(" (ascii \"");
        for(int i=0;i<8;i++) printf("%c", (g_key[i]>=0x20&&g_key[i]<0x7f)?g_key[i]:'.');
        printf("\") ***\n");
    } else {
        printf("\n[x] tidak ada kunci di charset '%s'. Perlu charset lain / GPU / FPGA.\n",name);
    }
    printf("[*] selesai dalam %llds\n",(long long)(time(NULL)-t0));
    return g_found?0:3;
}
